import React, { useState, useEffect } from 'react';

const CourseDashboard = () => {
  const [animateCards, setAnimateCards] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setAnimateCards(true), 500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="bg-white rounded-2xl shadow-lg p-6 w-96">
      <div className="mb-4">
        <h3 className="text-lg font-semibold text-gray-800 mb-2">Discover, connect and make branding skills</h3>
        <p className="text-blue-600 font-medium">Dive Into What's Hot Right Now! 🔥</p>
      </div>
      
      <div className="grid grid-cols-3 gap-4">
        {/* All Courses Card */}
        <div 
          className={`bg-gradient-to-br from-red-400 to-red-500 rounded-xl p-4 text-white transform transition-all duration-700 ${
            animateCards ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
          }`}
          style={{ transitionDelay: '0ms' }}
        >
          <div className="text-center">
            <div className="flex justify-center mb-2">
              <div className="w-8 h-8 bg-white bg-opacity-20 rounded-lg flex items-center justify-center">
                <span className="text-lg">📚</span>
              </div>
            </div>
            <div className="text-2xl font-bold">23</div>
            <div className="text-xs text-white text-opacity-90">All Courses</div>
            <div className="text-xs text-white text-opacity-75">Expert-led content</div>
          </div>
        </div>

        {/* Ongoing Courses */}
        <div 
          className={`bg-gradient-to-br from-pink-100 to-pink-200 rounded-xl p-4 text-pink-800 transform transition-all duration-700 ${
            animateCards ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
          }`}
          style={{ transitionDelay: '200ms' }}
        >
          <div className="text-center">
            <div className="flex justify-center mb-2">
              <div className="w-8 h-8 bg-pink-300 rounded-lg flex items-center justify-center">
                <span className="text-lg">⏳</span>
              </div>
            </div>
            <div className="text-2xl font-bold">05</div>
            <div className="text-xs">Ongoing</div>
            <div className="text-xs text-opacity-75">In Progress</div>
          </div>
        </div>

        {/* Completed Courses */}
        <div 
          className={`bg-gradient-to-br from-pink-100 to-pink-200 rounded-xl p-4 text-pink-800 transform transition-all duration-700 ${
            animateCards ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
          }`}
          style={{ transitionDelay: '400ms' }}
        >
          <div className="text-center">
            <div className="flex justify-center mb-2">
              <div className="w-8 h-8 bg-pink-300 rounded-lg flex items-center justify-center">
                <span className="text-lg">✅</span>
              </div>
            </div>
            <div className="text-2xl font-bold">10</div>
            <div className="text-xs">Completed</div>
            <div className="text-xs text-opacity-75">Finished</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CourseDashboard;