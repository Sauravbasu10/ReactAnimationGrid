import React, { useState, useEffect } from 'react';

const SocialProof = () => {
  const [animateAvatars, setAnimateAvatars] = useState(false);
  const [floatingIndex, setFloatingIndex] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => setAnimateAvatars(true), 500);
    const floatingTimer = setInterval(() => {
      setFloatingIndex(prev => (prev + 1) % 6);
    }, 2000);
    
    return () => {
      clearTimeout(timer);
      clearInterval(floatingTimer);
    };
  }, []);

  const avatars = [
    { id: 1, position: 'top-4 left-4', delay: '0ms', color: 'from-blue-400 to-purple-500' },
    { id: 2, position: 'top-4 right-4', delay: '200ms', color: 'from-green-400 to-blue-500' },
    { id: 3, position: 'top-20 left-20', delay: '400ms', color: 'from-pink-400 to-red-500' },
    { id: 4, position: 'bottom-20 left-4', delay: '600ms', color: 'from-yellow-400 to-orange-500' },
    { id: 5, position: 'bottom-4 right-4', delay: '800ms', color: 'from-purple-400 to-pink-500' },
    { id: 6, position: 'bottom-12 right-16', delay: '1000ms', color: 'from-indigo-400 to-blue-500' }
  ];

  return (
    <div className="bg-white rounded-2xl shadow-lg p-6 w-96 h-80 relative overflow-hidden">
      {/* Floating Avatars */}
      {avatars.map((avatar, index) => (
        <div
          key={avatar.id}
          className={`absolute w-12 h-12 rounded-full bg-gradient-to-r ${avatar.color} flex items-center justify-center text-white font-bold text-sm transform transition-all duration-1000 ${
            animateAvatars ? 'translate-y-0 opacity-100 scale-100' : 'translate-y-8 opacity-0 scale-50'
          } ${
            floatingIndex === index ? 'animate-bounce' : ''
          }`}
          style={{ 
            transitionDelay: avatar.delay,
            left: avatar.position.includes('left') ? '1rem' : undefined,
            right: avatar.position.includes('right') ? '1rem' : undefined,
            top: avatar.position.includes('top') ? '1rem' : undefined,
            bottom: avatar.position.includes('bottom') ? '1rem' : undefined,
          }}
        >
          {avatar.id}
        </div>
      ))}

      {/* Trophy Icon */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
        <div className="w-16 h-16 bg-yellow-400 rounded-full flex items-center justify-center text-2xl">
          🏆
        </div>
      </div>

      {/* Main Content */}
      <div className="absolute bottom-6 left-6 right-6 text-center">
        <h3 className="text-lg font-bold text-gray-800 mb-2">
          Hear How They Level Up Their Game!
        </h3>
        <p className="text-blue-600 font-semibold text-xl">
          Skill Masters Unite! 💪
        </p>
        <p className="text-sm text-gray-600 mt-1">
          View all Testimonials ➡️
        </p>
      </div>
    </div>
  );
};

export default SocialProof;