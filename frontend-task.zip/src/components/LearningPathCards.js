import React, { useState } from 'react';

const LearningPathCards = () => {
  const [activeCard, setActiveCard] = useState(null);

  return (
    <div className="bg-white rounded-2xl shadow-lg p-6 w-96">
      <div className="flex items-center mb-4">
        <div className="w-8 h-8 bg-gray-300 rounded-full mr-3"></div>
        <span className="text-sm text-gray-600">Hey! Pick Us Up, Stand Out... 🔥</span>
      </div>
      
      <div className="space-y-4">
        {/* Start with Clarity Card */}
        <div 
          className={`bg-gradient-to-r from-red-400 to-red-500 rounded-xl p-4 cursor-pointer transform transition-all duration-300 ${
            activeCard === 'clarity' ? 'scale-105 shadow-lg' : 'scale-100'
          }`}
          onMouseEnter={() => setActiveCard('clarity')}
          onMouseLeave={() => setActiveCard(null)}
        >
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <h3 className="text-white font-semibold text-lg mb-1">Start with Clarity</h3>
              <p className="text-white text-opacity-90 text-sm mb-3">
                This is the better learning path. Learn faster from the experts.
              </p>
              <button className="bg-white text-red-500 px-4 py-2 rounded-lg text-sm font-medium hover:bg-opacity-90 transition-colors">
                Get Started
              </button>
            </div>
            <div className="ml-4">
              <div className="w-16 h-16 bg-yellow-400 rounded-full flex items-center justify-center">
                <span className="text-2xl">👨‍💻</span>
              </div>
            </div>
          </div>
        </div>

        {/* Learn by Doing Card */}
        <div 
          className={`bg-gradient-to-r from-green-400 to-green-500 rounded-xl p-4 cursor-pointer transform transition-all duration-300 ${
            activeCard === 'doing' ? 'scale-105 shadow-lg' : 'scale-100'
          }`}
          onMouseEnter={() => setActiveCard('doing')}
          onMouseLeave={() => setActiveCard(null)}
        >
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <h3 className="text-white font-semibold text-lg mb-1">Learn by Doing</h3>
              <p className="text-white text-opacity-90 text-sm mb-3">
                Practice-based skills and expert-led content to help you level up.
              </p>
              <button className="bg-white text-green-500 px-4 py-2 rounded-lg text-sm font-medium hover:bg-opacity-90 transition-colors">
                Start Learning
              </button>
            </div>
            <div className="ml-4">
              <div className="w-16 h-16 bg-yellow-400 rounded-full flex items-center justify-center">
                <span className="text-2xl">🎯</span>
              </div>
            </div>
          </div>
        </div>

        {/* Additional Cards */}
        <div className="bg-purple-100 rounded-xl p-4">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <h3 className="text-purple-800 font-semibold text-lg mb-1">Get Mentored & Supported</h3>
              <p className="text-purple-700 text-sm mb-3">
                Have 1-on-1 learning conversations with our mentors.
              </p>
            </div>
            <div className="ml-4">
              <div className="w-16 h-16 bg-yellow-400 rounded-full flex items-center justify-center">
                <span className="text-2xl">👥</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-orange-100 rounded-xl p-4">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <h3 className="text-orange-800 font-semibold text-lg mb-1">Achieve & Showcase</h3>
              <p className="text-orange-700 text-sm mb-3">
                Build your portfolio and showcase your skills.
              </p>
            </div>
            <div className="ml-4">
              <div className="w-16 h-16 bg-yellow-400 rounded-full flex items-center justify-center">
                <span className="text-2xl">🏆</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LearningPathCards;