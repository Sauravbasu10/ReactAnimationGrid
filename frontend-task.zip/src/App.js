import React from 'react';
import LearningPathCards from './components/LearningPathCards';
import CourseDashboard from './components/CourseDashboard';
import SocialProof from './components/SocialProof';
import './App.css';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 to-blue-800 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-6xl font-bold text-white mb-4">
            Frontend<br />Assessment
          </h1>
          <div className="flex items-center justify-center text-white">
            <span className="text-lg">VritTech</span>
          </div>
        </div>

        {/* Components Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Top Right - Learning Path Cards */}
          <div className="flex justify-center lg:justify-end">
            <LearningPathCards />
          </div>

          {/* Bottom Left - Course Dashboard */}
          <div className="flex justify-center lg:justify-start">
            <CourseDashboard />
          </div>

          {/* Bottom Right - Social Proof */}
          <div className="flex justify-center lg:justify-end">
            <SocialProof />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;